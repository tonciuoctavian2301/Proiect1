<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *"); // Permite accesul

// Conectare la baza de date (Host-ul este 'db' din docker-compose)
$host = 'db';
$db   = 'scoala';
$user = 'user';
$pass = 'password';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo json_encode(["error" => "Eroare conectare DB: " . $e->getMessage()]);
    exit();
}

$method = $_SERVER['REQUEST_METHOD'];

// 1. GET - Trimite lista de studenți [cite: 94]
if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM studenti ORDER BY id DESC");
    $studenti = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($studenti);
} 

// 2. POST - Adaugă un student nou [cite: 98]
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (isset($data['nume'], $data['an'], $data['media'])) {
        $stmt = $pdo->prepare("INSERT INTO studenti (nume, an, media) VALUES (?, ?, ?)");
        if($stmt->execute([$data['nume'], $data['an'], $data['media']])) {
            echo json_encode(["status" => "success", "message" => "Student adaugat"]); 
        } else {
            echo json_encode(["status" => "error", "message" => "Nu s-a putut salva"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Date incomplete"]);
    }
}
?>