// src/script.js

// Funcție GET pentru afișarea listei
function incarcaLista() {
    fetch('api.php')
        .then(res => res.json())
        .then(data => {
            let html = '';
            // Verificăm dacă data este o listă (array) ca să nu avem erori
            if (Array.isArray(data)) {
                data.forEach(s => {
                    html += `<tr>
                        <td>${s.id}</td>
                        <td>${s.nume}</td>
                        <td>${s.an}</td>
                        <td>${s.media}</td>
                    </tr>`;
                });
            }
            document.getElementById('lista').innerHTML = html;
        })
        .catch(err => console.error("Eroare la încărcare:", err));
}

// Evenimentul de submit (POST)
// Folosim 'DOMContentLoaded' ca să fim siguri că HTML-ul s-a încărcat înainte să căutăm formularul
document.addEventListener('DOMContentLoaded', function() {
    
    // Încărcăm lista imediat ce pagina e gata
    incarcaLista();

    const form = document.getElementById('studentForm');
    
    form.addEventListener('submit', function(e) {
        e.preventDefault(); // Oprește refresh-ul paginii

        const student = {
            nume: document.getElementById('nume').value,
            an: document.getElementById('an').value,
            media: document.getElementById('media').value
        };

        fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(student)
        })
        .then(res => res.json())
        .then(raspuns => {
            if(raspuns.status === 'success') {
                incarcaLista(); // Actualizează lista
                form.reset();   // Golește formularul
            } else {
                alert('Eroare: ' + (raspuns.message || 'Necunoscută'));
            }
        })
        .catch(err => console.error("Eroare la salvare:", err));
    });
});