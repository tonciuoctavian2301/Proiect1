// Selectăm elementele din DOM
const input = document.getElementById("inputActivitate");
const buton = document.getElementById("btnAdauga");
const lista = document.getElementById("listaActivitati");

// Tablou cu lunile anului în limba română [cite: 176, 144]
const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// Adăugăm evenimentul de click pe buton [cite: 172]
buton.addEventListener("click", function() {
    const activitate = input.value;

    // Verificăm dacă inputul nu este gol [cite: 173]
    if (activitate !== "") {
        // 1. Creăm un nou element li [cite: 174]
        const elementNou = document.createElement("li");

        // 2. Obținem data curentă [cite: 175]
        const dataCurenta = new Date();
        const zi = dataCurenta.getDate();
        const lunaNume = luni[dataCurenta.getMonth()]; // Luna text
        const an = dataCurenta.getFullYear();

        // 3. Setăm textul elementului li (Activitate + Dată) [cite: 178-180]
        elementNou.textContent = `${activitate} - adăugată la: ${zi} ${lunaNume} ${an}`;

        // 4. Adăugăm elementul în listă [cite: 181]
        lista.appendChild(elementNou);

        // 5. Golim câmpul de input [cite: 183]
        input.value = "";
    } else {
        alert("Te rog introdu o activitate!");
    }
});