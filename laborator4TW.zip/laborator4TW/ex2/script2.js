// Tablou cu lunile anului
const luni = [
    "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
    "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
];

// La încărcarea paginii (codul rulează direct fiind la finalul body sau putem folosi window.onload) [cite: 199]

// 1. Selectăm elementele
const detaliiDiv = document.getElementById("detalii");
const btnDetalii = document.getElementById("btnDetalii");
const spanData = document.getElementById("dataProdus");

// 2. Ascundem detaliile inițial adăugând clasa "ascuns" [cite: 200]
detaliiDiv.classList.add("ascuns");

// 3. Afișăm data curentă formatată [cite: 201, 202]
const d = new Date();
const zi = d.getDate();
const luna = luni[d.getMonth()];
const an = d.getFullYear();

spanData.textContent = `${zi} ${luna} ${an}`;

// 4. Logica butonului la click [cite: 203]
btnDetalii.addEventListener("click", function() {
    // Comutăm vizibilitatea (scoate sau pune clasa 'ascuns') [cite: 205]
    detaliiDiv.classList.toggle("ascuns");

    // Modificăm textul butonului în funcție de stare [cite: 206-212]
    if (detaliiDiv.classList.contains("ascuns")) {
        // Dacă detaliile sunt ascunse
        btnDetalii.textContent = "Afișează detalii";
    } else {
        // Dacă detaliile sunt vizibile
        btnDetalii.textContent = "Ascunde detalii";
    }
});